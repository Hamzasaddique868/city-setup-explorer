# City Setup Explorer — Website Starter

A responsive, static website for Adnan Saddique Bhatti's livestock-market YouTube channel, covering Dera Ghazi Khan, Pakistan.

## Included
- Responsive homepage and navigation
- Goats, sheep, cows, bulls and buffalo categories
- Search, category filter and price sorting
- Listing details: breed, age, market, date, price source and qualities
- WhatsApp enquiry links
- YouTube channel link and optional featured video embed
- Editable listings in `listings.js`
- No backend, build tools or paid hosting required

## Important before publishing
The three listings currently in `listings.js` are DEMO EXAMPLES with illustrative prices. They are not real offers or verified market prices. Replace or remove them before publishing. Never describe seller claims as verified facts without checking them.

## Personalization already applied
- YouTube channel URL is set to `https://youtube.com/@city.setup.explorer?si=MMIZExj9Apki_Gqg`.
- WhatsApp contact is set to `923328246820` (international format without `+` or spaces).
- Market coverage is set to Kot Chutta Mundi, Dera Ghazi Khan.

## Personalize your website further
Open `listings.js` in a text editor and update:
1. `SITE_SETTINGS.youtubeUrl` with your channel URL.
2. `SITE_SETTINGS.whatsappNumber` with your WhatsApp number including country code and digits only (Pakistan example format: `923001234567`).
3. `SITE_SETTINGS.featuredVideoId` with the 11-character ID from a YouTube video URL, or leave it empty.
4. Replace the sample entries in `ANIMAL_LISTINGS` with your real listings.

Each listing supports:
- `id`: unique short ID
- `category`: `Goats`, `Sheep`, `Cows`, `Bulls`, or `Buffaloes`
- `title`, `breed`, `price` (number in PKR), `priceType` (e.g. `Asking price` or `Reported sale price`)
- `source`: `Reported by City Setup Explorer`, `Seller-submitted`, or another clear label
- `date`: `YYYY-MM-DD`
- `market`, `age`, `weight`, `qualities`
- `image`: image URL (leave empty to use an animal emoji placeholder)
- `sellerPhone`: optional note for your own records; not currently shown publicly
- `videoUrl`: optional YouTube video URL

Keep prices dated and distinguish asking prices from completed sale prices. Ask permission before publishing a seller's phone number or personal details. To protect your visitors, don't claim an animal's health, breed, weight or milk production is verified unless you have actually verified it.

## Preview on your computer
You can usually double-click `index.html` to open it in a browser. For a more reliable preview, use a local static server such as VS Code's Live Server extension.

## Publish free with GitHub Pages
1. Create or sign in to a GitHub account at https://github.com/.
2. Create a new **public** repository named `city-setup-explorer`.
3. Upload `index.html`, `styles.css`, `script.js`, `listings.js`, and this README to the repository root (not inside another folder).
4. Open repository **Settings → Pages**.
5. Under the build/deployment section, choose **Deploy from a branch**.
6. Choose branch `main` and folder `/ (root)`, then Save.
7. Wait for GitHub Pages to publish. Your site address will look like `https://YOUR-USERNAME.github.io/city-setup-explorer/`.
8. Test the website on a phone and computer.

GitHub's interface can change; if the menu labels differ, look for the Pages publishing/build settings. Hosting is free for a public repository. A custom domain is optional and usually costs money.

## Updating later
Edit `listings.js` on GitHub and commit the change. GitHub Pages will redeploy the updated site automatically. You can also replace photos and update video IDs there.

## Limitations of this first version
- Listings are manually maintained in a JavaScript file. There is no login dashboard or database.
- Seller submissions are handled through WhatsApp rather than automatically appearing on the site.
- The site doesn't automatically fetch YouTube uploads or live mandi prices.
- The Google Fonts and demo hero image need internet access to load.
