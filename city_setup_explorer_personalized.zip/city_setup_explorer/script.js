const money = value => "Rs " + Number(value).toLocaleString("en-PK");
const grid = document.getElementById("listingGrid");
const empty = document.getElementById("emptyState");
const demoDisclaimer = document.getElementById("demoDisclaimer");

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  })[char]);
}
function dateLabel(value) {
  if (!value) return "Date not added";
  const d = new Date(value + "T00:00:00");
  return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"});
}
function iconFor(category) {
  return ({Goats:"🐐",Sheep:"🐑",Cows:"🐄",Bulls:"🐂",Buffaloes:"🐃"})[category] || "🐄";
}
function listingCard(item) {
  const isDemo = item.source === "Demo listing";
  const image = item.image
    ? `<img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.title)}" loading="lazy">`
    : `<span aria-hidden="true">${iconFor(item.category)}</span>`;
  const whatsapp = SITE_SETTINGS.whatsappNumber
    ? `https://wa.me/${encodeURIComponent(SITE_SETTINGS.whatsappNumber)}?text=${encodeURIComponent("Hello, I am asking about: " + item.title + " (" + item.category + ") listed on City Setup Explorer.")}`
    : `https://wa.me/?text=${encodeURIComponent("Hello, I am asking about: " + item.title + " (" + item.category + ") listed on City Setup Explorer. Please add the site owner's WhatsApp number in listings.js.")}`;
  const video = item.videoUrl ? `<a class="secondary" href="${escapeHtml(item.videoUrl)}" target="_blank" rel="noopener">Watch video ↗</a>` : "";
  return `<article class="animal-card">
    <div class="animal-image">${image}<span class="animal-badge">${escapeHtml(item.source || "Price source not set")}</span></div>
    <div class="animal-body">
      <span class="animal-type">${escapeHtml(item.category)}</span>
      <h3>${escapeHtml(item.title)}</h3>
      <div class="animal-price">${money(item.price)} <small>· ${escapeHtml(item.priceType || "Price type not set")}</small></div>
      <div class="animal-meta">
        <div><span class="meta-label">Breed</span><span class="meta-value">${escapeHtml(item.breed || "Not provided")}</span></div>
        <div><span class="meta-label">Age</span><span class="meta-value">${escapeHtml(item.age || "Not provided")}</span></div>
        <div><span class="meta-label">Market</span><span class="meta-value">${escapeHtml(item.market || "Not provided")}</span></div>
        <div><span class="meta-label">Price checked</span><span class="meta-value">${dateLabel(item.date)}</span></div>
      </div>
      <p class="animal-description">${escapeHtml(item.qualities || "No quality details provided.")}${item.weight ? " Weight: " + escapeHtml(item.weight) + "." : ""}</p>
      <div class="animal-actions"><a href="${whatsapp}" target="_blank" rel="noopener">Ask on WhatsApp ↗</a>${video}</div>
    </div>
  </article>`;
}
function renderListings() {
  const query = document.getElementById("searchInput").value.trim().toLowerCase();
  const category = document.getElementById("categoryFilter").value;
  const sort = document.getElementById("sortFilter").value;
  let items = ANIMAL_LISTINGS.filter(item => {
    const haystack = [item.title,item.category,item.breed,item.market,item.qualities,item.source].join(" ").toLowerCase();
    return (category === "All" || item.category === category) && haystack.includes(query);
  });
  items.sort((a,b) => sort === "low" ? a.price-b.price : sort === "high" ? b.price-a.price : String(b.date).localeCompare(String(a.date)));
  grid.innerHTML = items.map(listingCard).join("");
  empty.hidden = items.length > 0;
  demoDisclaimer.hidden = !ANIMAL_LISTINGS.some(item => item.source === "Demo listing");
}
document.getElementById("searchInput").addEventListener("input", renderListings);
document.getElementById("categoryFilter").addEventListener("change", renderListings);
document.getElementById("sortFilter").addEventListener("change", renderListings);
document.querySelectorAll("[data-shortcut]").forEach(link => link.addEventListener("click", () => {
  document.getElementById("categoryFilter").value = link.dataset.shortcut;
  renderListings();
}));
document.getElementById("year").textContent = new Date().getFullYear();
document.getElementById("youtubeLink").href = SITE_SETTINGS.youtubeUrl || "https://www.youtube.com/";
const waLink = document.getElementById("whatsappLink");
if (SITE_SETTINGS.whatsappNumber) {
  waLink.href = "https://wa.me/" + SITE_SETTINGS.whatsappNumber + "?text=" + encodeURIComponent("Hello City Setup Explorer, I have a livestock-market update.");
} else {
  waLink.href = "https://wa.me/?text=" + encodeURIComponent("Hello City Setup Explorer, I have a livestock-market update. Please share your WhatsApp contact.");
}
const videoBox = document.querySelector(".video-placeholder");
if (SITE_SETTINGS.featuredVideoId && /^[\w-]{11}$/.test(SITE_SETTINGS.featuredVideoId)) {
  videoBox.innerHTML = `<iframe title="Featured City Setup Explorer YouTube video" width="100%" height="315" src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(SITE_SETTINGS.featuredVideoId)}" style="border:0;border-radius:14px" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen loading="lazy"></iframe>`;
}
const menuToggle = document.getElementById("menuToggle");
const nav = document.getElementById("mainNav");
menuToggle.addEventListener("click", () => {
  const opened = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(opened));
});
nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
  nav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded","false");
}));
renderListings();
